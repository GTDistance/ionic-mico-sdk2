/*
       Author KongYang,COOLTOUCH CHINA.
       Contact: 4008-7676-82
 */
package com.chengputech.coolcloud;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaResourceApi;
import org.apache.cordova.LOG;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;

//import com.mxchip.easylink.EasyLinkAPI;
//import com.mxchip.easylink.FTCListener;
import com.mxchip.ftc_service.FTC_Listener;
import com.mxchip.ftc_service.FTC_Service;
import com.mxchip.helper.EasyLinkWifiManager;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.content.pm.PackageManager;

/**
 * This class launches the camera view, allows the user to take a picture,
 * closes the camera view, and returns the captured image. When the camera view
 * is closed, the screen displayed before the camera view was shown is
 * redisplayed.
 */
public class MicoSDK extends CordovaPlugin {
	private EasyLinkWifiManager mWifiManager = null;
	private FTC_Service ftcService = null;
	private Socket socket = null;
//	public EasyLinkAPI elapi;

	@Override
	public boolean execute(String action, final JSONArray args,
			final CallbackContext callbackContext) throws JSONException {
		if ("beep".equals(action)) {
			callbackContext.success("micro sdk !!!");
			return true;
		} else if ("getSsid".equals(action)) {
			mWifiManager = new EasyLinkWifiManager(webView.getContext());
			callbackContext.success(mWifiManager.getCurrentSSID());
			return true;
		} else if("configFTC".equals(action)) {
			OutputStream outputStream;
			try {
				outputStream = socket.getOutputStream();
				String toSend = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: "+args.getString(0).toString().length()+"\r\n\r\n"+args.getString(0).toString();
				outputStream.write(toSend.getBytes());
				ftcService.stopTransmitting();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				ftcService.stopTransmitting();
				e.printStackTrace();
			}
			callbackContext.success("true");
			
		} else if ("search".equals(action)) {
//			if(elapi!=null) {
//				elapi.stopFTC();
//				elapi.stopEasyLink();
//			}
//			elapi = new EasyLinkAPI(cordova.getActivity());
			cordova.getThreadPool().execute(new Runnable() {
                public void run() {
                	try {
                		if(ftcService != null) {
                			ftcService.stopTransmitting();
                			ftcService = null;
                		}
            			ftcService = FTC_Service.getInstence();
            			
            			ftcService.transmitSettings(args.getString(0), args.getString(1).toString(), "{\"from\":\"coolcloud\"}", mWifiManager.getCurrentIpAddressConnectedInt(),
            					new FTC_Listener(){

							@Override
							public void onFTCfinished(Socket s,
									String jsonString) {
								// TODO Auto-generated method stub
								socket = s;
//								OutputStream outputStream;
//								try {
//									outputStream = s.getOutputStream();
//									outputStream.write("just a test\r\n\r\n".getBytes());
//									
//									ftcService.stopTransmitting();
//								} catch (IOException e) {
//									// TODO Auto-generated catch block
//									ftcService.stopTransmitting();
//									e.printStackTrace();
//								}
								callbackContext.success(jsonString);
								
							}

							@Override
							public void isSmallMTU(int MTU) {
								// TODO Auto-generated method stub
								
							}
            				
            			});
//        				elapi.startEasyLink_FTC(cordova.getActivity(), args.getString(0)
//        						.trim(), args.getString(1).toString(),
//        						"{\"from\":\"coolcloud\"}", new FTCListener() {
//        							@Override
//        							public void onFTCfinished(String ip, String jsonString) {
//        								Log.i("wifi",jsonString);
//        								callbackContext.success(jsonString);
//        								elapi.stopEasyLink();
//        							}
//        							@Override
//        							public void isSmallMTU(int MTU) {
//        							}
//        						});
        			} catch (JSONException e) {
        				// TODO Auto-generated catch block
        				callbackContext.error("Wifi Init Error!");
        			}   
                }
            });
			 
                	
			return true;
		} else if ("stop".equals(action)) {
			if(ftcService != null) {
				ftcService.stopTransmitting();
			}
//			elapi.stopFTC();
//			elapi.stopEasyLink();
			return true;
		}
		return false; // Returning false results in a "MethodNotFound" error.
	}
}
