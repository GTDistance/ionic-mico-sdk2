package com.mxchip.udpSearch;

public interface udpSearch_Listener {
	public void onDeviceFound(String jsonString);
}
